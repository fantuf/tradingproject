﻿public class ResultRow
{
    public string Ticker { get; set; }
    public string Decision { get; set; }
    public double WeightDiff { get; set; }
}


﻿using HtmlAgilityPack;
using OfficeOpenXml;
using System.Collections.Specialized;
using System.Configuration;
using System.Drawing;
using System.Globalization;
using System.Text.RegularExpressions;

public class Program
{
    private static async Task Main(string[] args)
    {

        var httpClient = new HttpClient();

        httpClient.DefaultRequestHeaders.Add("User-Agent","USI pryimousi.ch");

        //Get list of companies from S&P500
        var snpList = await getSnPDataAsync(httpClient);

        var excelFilesPath = Path.Combine(Directory.GetCurrentDirectory(),"ExcelFiles");


        #region CUSIP_Extraction

        var cusipData = new Dictionary<string,string>();

        //Extract CUSIP for each S&P500 company from quantumonline.com
        Console.WriteLine("CUSIP extraction started");
        foreach(var ticker in snpList)
        {
            var url = ConfigurationManager.AppSettings["quantumonlineUrl"].Replace("{ticker_placeholder}",ticker.Symbol);

            //HTTP request
            var htmlString = await httpClient.GetStringAsync(url);

            //Regex expression to find CUSIP in HTTP response 
            string pattern = @"CUSIP:\s*([A-Z0-9]+)";

            Match match = Regex.Match(htmlString,pattern);
            if(match.Success)
            {
                string cusip = match.Groups[1].Value;
                cusipData.Add(ticker.Symbol,cusip);
            } else
            {
                Console.WriteLine($"Couldn't find CUSIP for: {ticker.Symbol}");
            }
        }

        Console.WriteLine("CUSIP extraction finished");

        #endregion

        //Get CIK value for each financial institution from configuration file
        var companiesConfig = ConfigurationManager.GetSection("FinInst_CIK") as NameValueCollection;

        var companiesHoldings = new List<List<StockRecord>>();


        //Web scraping for each financial institution
        #region Get_FinancialInst_Holdings

        foreach(string key in companiesConfig.Keys)
        {
            Console.WriteLine($"Scraping of {key} started.");

            //Get HTML page with all 13F filings for given financial institution
            var url = ConfigurationManager.AppSettings["getFilingsTemplate"].Replace("{CIK_placeholder}",companiesConfig[key]);

            httpClient.DefaultRequestHeaders.Add("Accept","*/*");

            var html = await httpClient.GetStringAsync(url);

            var doc = new HtmlDocument();
            doc.LoadHtml(html);

            //Find a link to the last filing detail page in HTML code
            var divNode = (doc.DocumentNode
                .SelectSingleNode("//div[@id='seriesDiv']"));
            var divDoc = new HtmlDocument();
            divDoc.LoadHtml(divNode.InnerHtml);
            var hrefNode = divDoc.DocumentNode.SelectSingleNode("//table[@class='tableFile2']")
                .SelectNodes("//tr")[1]
                .SelectNodes("//td")[1]
                .SelectSingleNode("//a");


            if(hrefNode != null)
            {

                //Get HTML page with filing detail
                url = ConfigurationManager.AppSettings["secHost"] + hrefNode.GetAttributeValue("href",string.Empty);

                html = await httpClient.GetStringAsync(url);

                var filingDetailDoc = new HtmlDocument();
                filingDetailDoc.LoadHtml(html);

                //Find a link to a file with all of the financial institution holdings
                var holdingRefNode = filingDetailDoc.DocumentNode.SelectSingleNode("//tr[td[text()='INFORMATION TABLE'] and td[a[text()[contains(.,'.html')]]]]");
                if(holdingRefNode != null)
                {
                    var aNodeDoc = new HtmlDocument();
                    aNodeDoc.LoadHtml(holdingRefNode.InnerHtml);
                    var holdingsRefNode = aNodeDoc.DocumentNode.SelectNodes("//td")[2].SelectSingleNode("//a");

                    //Get HTML page of the holdings file 
                    url = ConfigurationManager.AppSettings["secHost"] + holdingsRefNode.GetAttributeValue("href",string.Empty);

                    html = await httpClient.GetStringAsync(url);

                    var holdingsDoc = new HtmlDocument();
                    holdingsDoc.LoadHtml(html);

                    var rowNodes = holdingsDoc.DocumentNode.SelectNodes("//tr[td[@class='FormData']]");

                    long totalValue = 0;

                    var stockRecords = new List<StockRecord>();

                    //Scrape data for each row from the holdings table
                    foreach(var row in rowNodes)
                    {
                        var columns = row.ChildNodes.Where(x => x.Name == "td").ToList();

                        //If holding is not a "Common Stock" type or S&P500 doesn't contain this stock then ignore it
                        if(!ConfigurationManager.AppSettings["classTitles"].Contains(columns[1].InnerText) ||
                            !cusipData.Values.Contains(columns[2].InnerText))
                            continue;

                        //Get a value of the holding
                        var valueTmp = long.Parse(columns[4].InnerText.Replace(",",""));

                        totalValue += valueTmp;

                        var existingRecord = stockRecords.FirstOrDefault(x => x.Name == columns[0].InnerText);

                        //If it isn't the first instance of the holding then update its value. Otherwise, create a new record
                        if(existingRecord != null)
                        {
                            existingRecord.Value += valueTmp;
                        } else
                        {
                            stockRecords.Add(new StockRecord
                            {
                                Name = columns[0].InnerText,
                                CUSIP = columns[2].InnerText,
                                Value = long.Parse(columns[4].InnerText.Replace(",",""))
                            });
                        }
                    }

                    //Get weight for each stock
                    stockRecords.ForEach(stock =>
                    {
                        stock.Percentage = ((double)stock.Value / (double)totalValue) * 100;
                    });
                    companiesHoldings.Add(stockRecords);
                }
            }
            Console.WriteLine($"Scraping of {key} finished.");
        }

        #endregion


        #region Compare_weights_w/S&P500

        Console.WriteLine("Weights calculation started.");

        //Flatten the list of lists
        var allHoldings = companiesHoldings.SelectMany(company => company);

        //Get only stocks that exist in more than 5 financial institutions reports
        var filteredCUSIPs = allHoldings
            .GroupBy(holding => holding.CUSIP)
            .Where(group => group.Count() > 5)
            .Select(group => group.Key);

        // Group by CUSIP and calculate the average value for each stock
        var avgPercentByCUSIP = allHoldings
            .Where(holding => filteredCUSIPs.Contains(holding.CUSIP))
            .GroupBy(holding => holding.CUSIP)
            .Select(group => new
            {
                CUSIP = group.Key,
                AvgValue = group.Average(holding => holding.Percentage)
            });

        var resultList = new List<ResultRow>();

        //Calculate weight difference for each stock
        foreach(var stock in avgPercentByCUSIP)
        {
            var ticker = cusipData.FirstOrDefault(x => x.Value == stock.CUSIP).Key;

            var snpRecord = snpList.FirstOrDefault(x => x.Symbol == ticker);

            var weightDiff = snpRecord.Percentage - stock.AvgValue;

            //Create list of objects to be populated into a result table
            resultList.Add(new ResultRow
            {
                Ticker = ticker,
                Decision = weightDiff >= 0 ? "BUY" : "SELL",
                WeightDiff = weightDiff,
            });
        }

        Console.WriteLine("Weights calculation finished.");
        #endregion

        //Export results to an excel table
        ExportToExcel(resultList,excelFilesPath);

        Console.ReadLine();
    }


    private static async Task<List<Company>> getSnPDataAsync(HttpClient httpClient)
    {
        Console.WriteLine("SnP500 extraction started.");

        //Get HTML page with S%NP500
        var snpUrl = ConfigurationManager.AppSettings["snpUrl"];
        var snphtml = await httpClient.GetStringAsync(snpUrl);

        var htmlDocument = new HtmlDocument();
        htmlDocument.LoadHtml(snphtml);

        //Scrape S&P500 table
        var companiesTable = htmlDocument.DocumentNode.SelectSingleNode("//table[@class='table table-hover table-borderless table-sm']");

        var companiesList = new List<Company>();

        foreach(var row in companiesTable.SelectNodes("//tr"))
        {
            var nodes = row.SelectNodes("td");
            if(nodes != null)
            {
                companiesList.Add(new Company
                {
                    Name = nodes[1].InnerText,
                    Symbol = nodes[2].InnerText,
                    Percentage = float.Parse(nodes[3].InnerText.Trim('%'),CultureInfo.InvariantCulture)
                });
            }
        }
        Console.WriteLine("SnP500 extraction finished.");
        return companiesList;
    }

    private static void ExportToExcel(List<ResultRow> list,string folderPath)
    {
        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

        //Create an Excel package
        using(var package = new ExcelPackage())
        {
            //Add a worksheet to the Excel package
            ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Results");

            //Add headers
            worksheet.Cells[1,1].Value = "Ticker";
            worksheet.Cells[1,2].Value = "Decision";
            worksheet.Cells[1,3].Value = "WeightDiff";

            //Populate data from the list
            int row = 2; 
            foreach(var result in list)
            {
                worksheet.Cells[row,1].Value = result.Ticker;
                worksheet.Cells[row,2].Value = result.Decision;
                worksheet.Cells[row,3].Value = result.WeightDiff;

                if(result.Decision == "BUY")
                {
                    worksheet.Cells[row,2].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                    worksheet.Cells[row,2].Style.Fill.BackgroundColor.SetColor(Color.Green);
                } else
                {
                    worksheet.Cells[row,2].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                    worksheet.Cells[row,2].Style.Fill.BackgroundColor.SetColor(Color.Red);
                }
                row++;
            }

            // Save the Excel package to a file
            if(!Directory.Exists("folderPath"))
                Directory.CreateDirectory(folderPath);

            FileInfo excelFile = new FileInfo(Path.Combine(folderPath,"Results.xlsx"));
            package.SaveAs(excelFile);
        }
        Console.WriteLine("Excel file created successfully.");
    }
}



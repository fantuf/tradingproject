﻿
public class Company
{
    public string Name { get; set; }
    public string Symbol { get; set; }
    public double Percentage { get; set; }
}

